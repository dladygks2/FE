import '../app.css';

function Con1(){
    return(
        <div className='con1'>con1</div>
    )
}

export default Con1;