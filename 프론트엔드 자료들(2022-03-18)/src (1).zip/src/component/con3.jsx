import '../app.css';

function Con3(){
    return(
        <div className='con3'>con3</div>
    )
}

export default Con3;