import '../app.css';

function Footer_in({children}){
    return(
        <div className='footer_in'>
         {children}  
        </div>
    )
}


export default Footer_in;