import '../app.css';

function Con2(){
    return(
        <div className='con2'>con2</div>
    )
}

export default Con2;