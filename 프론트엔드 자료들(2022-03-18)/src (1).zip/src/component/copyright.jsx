import '../app.css';

function Copyright({children}){
 return( 
    <div className='copyright'>
        {children}
    </div>
 )   
}

export default Copyright;