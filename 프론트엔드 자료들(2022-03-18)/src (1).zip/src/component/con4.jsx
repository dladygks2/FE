import '../app.css';

function Con4(){
    return(
        <div className='con4'>con4</div>
    )
}

export default Con4;