import React, { useRef, useState, useMemo }  from "react";
//import Counter from "./component/counter";
//import Input from "./component/input";
//import MultiInput from './component/multiinput';
//import UserList from "./component/userlist";
import CreateUser from "./component/createUser";
import UserList2 from "./component/userlist2";

function countActiveUser(users){
  console.log('선택된 사용자 수');
  return users.filter(user => user.active).length;
}

function App() {
  const[inputs,setInputs] = useState({
    username: '',
    email: ''
  });

  const { username, email } = inputs;//비구조 할당

  const onChange = e => {
    const { name, value } = e.target;
    setInputs({
      ...inputs,
      [name]: value 
    });
  };

  const [users, setUsers] = useState([
    { //user
        id: 1,
        username: '김사과',
        email: 'apple@apple.com'
    },
    {
        id: 2,
        username: '오렌지',
        email: 'orange@orange.com'
    },
    {
        id: 3,
        username: '반하나',
        email: 'banana@banana.com'
    },
    {
        id: 4,
        username: '이메론',
        email: 'melon@melon.com'
    },
    {
        id: 5,
        username: '배애리',
        email: 'berry@berry.com'
    }
]);

const nextId = useRef(6);//배열의 위치를 객체값으로 설정

const onCreate = () => {
    const user ={
     id: nextId.current,
     username,
     email
    };

    //setUsers([...users, user]);
    setUsers(users.concat(user));//배열에 저장

    setInputs({//입력후 빈공백으로 설정
      username: '',
      email: ''
    })
    nextId.current += 1;//다음으로 입력된 배열요소의 id값
};

const onRemove = id => {
  // user.id가 파라미터로 일치하지 않는 원소만 추출해서 새로운 배열을 만듬
  // user.id가 id인 것을 제거함
   setUsers(users.filter(user => user.id !== id));
}

const onToggle = id => {
   setUsers(
    users.map(user => user.id === id ? { ...user, active: !user.active } : user)
   );
}

const count = useMemo( () => countActiveUser(users), [users]);

  return (
    <>
    {/* <Counter/> */}
    {/* <Input/> */}
    {/* <MultiInput/> */}
    {/* <UserList/> */}
    <CreateUser
     username={username}
     email={email}
     onChange={onChange}
     onCreate={onCreate}
    />
    <UserList2 users={users} onRemove={onRemove} onToggle={onToggle}/>
    <div>선택된 사용자 수 : {count}</div>
    </>
  );
}

export default App;
