import React from "react";


function Home(){
  return(
   <div>
    <h1>홈입니다</h1>
    <p>리액트 라우터 연결 테스트 첫페이지입니다</p>
   </div>
  )
} 

export default Home