import React from "react";

const Apple = () => {

  <p>애플페이지입니다</p>

}


export default Apple;