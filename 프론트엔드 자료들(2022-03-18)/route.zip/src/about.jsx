import React from 'react';

const About = () => {
 
    return (
        <div>
            <h1>소개</h1>
            <p>리액트 라우터를 공부하고 있어요</p>
           
        </div>
    );
};

export default About;