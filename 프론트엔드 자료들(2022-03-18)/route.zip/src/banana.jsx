import React from "react";

const Banana = () => {

  <p>바나나페이지입니다</p>

}


export default Banana;