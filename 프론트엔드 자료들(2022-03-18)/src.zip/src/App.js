import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>리액트 최초로 실행</div>
  );
}

export default App;
